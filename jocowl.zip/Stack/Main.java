import java.util.Stack;
class Main {
  public static void main(String[] args) {
    Stack<Integer> stack= new Stack<Integer>();
    stack.push(1);
    stack.push(44);
    stack.push(3);
    stack.push(23);
    System.out.println(stack.peek());
  }
}