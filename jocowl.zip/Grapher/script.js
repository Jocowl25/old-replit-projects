console.clear() 
let sel; const yvalues = []; const xvalues = []; var inpl = []; var pressed = 0; var inplt = []; var x; var type = 1; var asy = []; var xst = 0; /*starting x value*/var gmax = 11; /*end x value*/var xinc = 0.1; /*value to increment x by*/var inp; const images = []; const num = "1234567890."; const ftype = 9; const operations = "(^*/+-)"; 

function preload() {
  images[0] = loadImage("Images/0.1 graph.png");
  images[1] = loadImage("Images/Trig2.png");
  images[3] = loadImage("Images/AAAA.png");
  images[4] = loadImage("Images/50 graph.png");
  images[5] = loadImage("Images/100 graph.png");
  images[6] = loadImage("Images/500 graph.png");
} //preloads images

function setup() {
  createCanvas(600, 400);
  background("white");
  textSize(20);
  txt()
  let inp = createInput("");
  inp.position(25, 13);
  inp.size(100)
  inp.input((inp = Input));
  sel = createSelect();
  sel.position(450, 15);
  sel.option("Graph Zoom: Decimal");
  sel.option("Graph Zoom: Trig");
  sel.option("Graph Zoom: Standard");
  sel.option("Graph Zoom: Medium");
  sel.option("Graph Zoom: Large");
  sel.option("Graph Zoom: XLarge");
  sel.selected("Graph Zoom: Standard");
  setGraph()
  sel.changed(setGraph);
} //loads textbox and buttons

function setGraph() {
  // xst = starting x value
//gmax = end x value
 //xinc =  value to increment x by
  clear()
  txt()
  
  switch (sel.value()) {
    case "Graph Zoom: Decimal": {
      image(images[0], 0, 20,width,height, 0, 0, images[0].width, images[0].height, CONTAIN)
      xst=-1.1
      gmax=1.1
      xinc=0.01
      break;
    }
    case "Graph Zoom: Trig": {
      image(images[1], 0, 20,width,height, 0, 0, images[1].width, images[1].height, CONTAIN);
      xst= -5.5*(PI/2)
      gmax= 5.5*(PI/2)
      xinc=0.001*(PI/2)
      break;
    }
    case "Graph Zoom: Standard": {
      image(images[3], 0, 20, width, height, 0, 0, images[3].width, images[3].height,CONTAIN);
      xst=-11
      gmax=11
      xinc=0.05
      break;
    }
    case "Graph Zoom: Medium": {
      image(images[4], 0, 20,width,height, 0, 0, images[4].width, images[4].height,CONTAIN);
      xst=-55
      gmax=55
      xinc=0.05
      break;
    }
    case "Graph Zoom: Large": {
      image(images[5], 0, 20,width,height, 0, 0, images[5].width, images[5].height,CONTAIN);
      xst=-105
      gmax=105
      xinc=0.5
      break;
    }
    case "Graph Zoom: XLarge": {
      image(images[6], 0, 20,width,height, 0, 0, images[6].width, images[6].height,CONTAIN);
      xst=-550
      gmax=550
      xinc=1
      break;
    }
  }
  if (inp!==undefined) {
    Input2()
  }
  fun()
} //loads images and intervals

function draw() {
  if (keyIsPressed == true && keyCode === ENTER && pressed == 0) {
    clear()
    setGraph();
    pressed = 1;
    Input2()
    noFill();
  }
} //checks if texbox is submitted

function Input() {
  inp = this.value();
} //sets textbox input to var

function Input2() {
  x = xst;
  asy.length = 0;
  inpl.length = 0;
  inplt.length = 0;
  yvalues.splice(0, yvalues.length);
  xvalues.splice(0, xvalues.length);

  //change this later to graph spec
  while (x < gmax) {
    list(inp);
    while (type < ftype + 2) {
      decode(type, inpl);
      type++;
      type++;
    }
    type = 1;
    if (inpl.length<2) {
    xvalues.push(Math.round(x*10000)/10000);
    yvalues.push(Math.round(inpl[0]*10000)/10000);
    }
    x = Math.round((x+xinc)*10000)/10000;
     
    
  }
  fun();
  pressed=0;
} //turns x inputs to y outputs

function list(inp) {
  inpl.length = 0;
  inplt.length = 0;
  var i = 1;
  var prevnum = null;
  var char;
  var done = 0;
  while (i <= inp.length) {
    char = inp.charAt(i - 1); //updates current char of input

    if (num.includes(char) == true) {
      //if current char is a number
      if (prevnum == null) {
        prevnum = char;
      } else {
        prevnum = prevnum.concat(char);
      } // this entire line gets prevnum to work
    } else {
      if (prevnum !== null && done !== 1) {
        inpl.push(parseFloat(prevnum), char);
        inplt.push(parseFloat(prevnum), char);
        done = 1;
        prevnum = null;
        
      }
      //do after stuff?
    }
    if (i == inp.length && prevnum !== null && done !== 1) {
      inpl.push(parseFloat(prevnum));
      inplt.push(parseFloat(prevnum));
      done = 1;
      prevnum = null;
    }
    if (prevnum == null && done !== 1) {
      inpl.push(char);
      inplt.push(char);
      done = 1;
      prevnum = null;
    }

    done = 0;
    i++;
  }

} //puts input in list form

function decode(t, inpl) {
  // type increases by 2 each time- make sure to count for both current operation and operation before (to work with pemdas) (OUTDATED, but kept anyway for consistency)
  for (var char = 0; char <= inpl.length; char++) {
    

    switch (
      t //type is every other odd number!!!!!!
    ) {
      case 1: {
         if (inplt[char] == "π")  {
          inpl.splice(char, 1, PI);
           console.log("test",inpl)
           break;
        }
        if (inplt[char] == "x") {
          inpl.splice(char, 1, x);
          break;
        }
        if (inplt[char] == "e" && inplt[char+1]!=="c") {
          inpl.splice(char, 1, Math.E);
          break;
        }
       
        break;
      } //special char
      case ftype - 6: {
        
        //stuff stuff

        if (inpl[char] == "(") {
          //"sin","cos" , "tan","log"
          var fspec = 0;
     if    (inpl[char - 2] + inpl[char - 1]== "ln") {
       fspec=5;
     }
         switch (inpl[char-5]+inpl[char-4]+ inpl[char - 3] + inpl[char - 2] + inpl[char - 1]) {
          case "asinh": {
              fspec = 16;
              break;
            }
          case "acosh": {
              fspec = 17;
              break;
            }
          case "atanh": {
              fspec = 18;
              break;
            } 
          case "acsch": {
              fspec = 19;
              break;
            }
          case "asech": {
              fspec = 20;
              break;
            }
          case "acoth": {
              fspec = 21;
              break;
            } 
         }
          
          if(fspec==0) {
          switch (inpl[char-4]+ inpl[char - 3] + inpl[char - 2] + inpl[char - 1]) {
          case "sinh": {
              fspec = 10;
              break;
            }
          case "cosh": {
              fspec = 11;
              break;
            }
          case "tanh": {
              fspec = 12;
              break;
            }   
          case "asin": {
              fspec = 13;
              break;
            }
          case "acos": {
              fspec = 14;
              break;
            }
          case "atan": {
              fspec = 15;
              break;
            }
          case "sqrt": {
            fspec = 15.5;
              break;
            }
          case "cbrt": {
              fspec = 15.6;
              break;
            }
          case "csch": {
              fspec = 15.7;
              break;
            }
          case "sech": {
              fspec = 15.8;
              break;
            }
          case "coth": {
              fspec = 15.9;
              break;
            }  
         }
         }
          if (fspec==0) {
          switch (inpl[char - 3] + inpl[char - 2] + inpl[char - 1]) {
          case "sin": {
              fspec = 1;
              break;
            }
          case "cos": {
              fspec = 2;
              break;
            }
          case "tan": {
              fspec = 3;
              break;
            }              
          case "log": {
              fspec = 4;
              break;
            }  
          case "abs": {
              fspec = 6;
              break;
            }
          case "sec": {
              fspec = 8;
              break;
            }
          case "csc": {
              fspec = 7;
              break;
            }
          case "cot": {
              fspec = 9;
              break;
            }
          }
          }

          var charsave = char;
          var temptype = 3;
          var inpb = [];
          var brack = 1; //bracket check
          for (char++; brack !== 0 || char==inpl.length+1; char++) {
            if (inpl[char] == "(") {
              brack++;
            }
            if (inpl[char] == ")") {
              brack--;
            }
            if (char>inpl.length+1) {
              break;
            }
            if (brack !== 0) {
              inpb.push(inpl[char]);
            }
          }
          var bil = inpb.length;
          while (temptype < ftype + 2) {
            decode(temptype, inpb);
            temptype++;
            temptype++;
          }
          char = charsave;
          if (fspec!==0) {
            switch (fspec) {
          case 1: {
              inpb[0]=Math.sin(inpb[0]);
              break;
            }//sin
          case 2: {
              inpb[0]=Math.cos(inpb[0]);
              break;
            }//cos
          case 3: {
              if (Math.round(cos(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
              inpb[0]=Math.tan(inpb[0]);
              break;
            }//tan
          case 4: {
              inpb[0]=Math.log10(inpb[0]);
              break;
            }//log
          case 5: {
              inpb[0]=Math.log(inpb[0]);
              break;
            }//ln
          case 6: {
              inpb[0]=Math.abs(inpb[0]);
              break;
            }//abs
          case 7: {
            if (Math.round(sin(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
            inpb[0]=1/(Math.sin(inpb[0]));
              break;
            }//csc
          case 8: {
            if (Math.round(cos(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
            inpb[0]=1/(Math.cos(inpb[0]));
              break;
            }//sec
          case 9: {
            if (Math.round(tan(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
               asy.push(x)   
                  }
              inpb[0]=1/(Math.tan(inpb[0]));
              break;
            }//cot
          case 10: {
              inpb[0]=Math.sinh(inpb[0]);
              break;
            }//sinh
          case 11: {
              inpb[0]=Math.cosh(inpb[0]);
              break;
            }//cosh
          case 12: {
              if (Math.round(Math.cosh(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
              inpb[0]=Math.tanh(inpb[0]);
              break;
            }//tanh
          case 13: {
            inpb[0]=asin(inpb[0]);
              break;
            }//asin     
          case 14: {
              inpb[0]=acos(inpb[0]);
              break;
            }//acos
          case 15: {
              inpb[0]=atan(inpb[0]);
              break;
            }//atan
          case 15.5: {                     
            inpb[0]=sqrt(inpb[0]);
              break;
          } //sqrt
          case 15.6: {
          inpb[0]=Math.cbrt(inpb[0]);
              break;
          } //cbrt
          case 15.7: {
            if (Math.round(Math.sinh(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
            inpb[0]=1/(Math.sinh(inpb[0]));
              break;
            }//csch
          case 15.8: {
            if (Math.round(Math.cosh(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
                asy.push(x)   
                  }
            inpb[0]=1/(Math.cosh(inpb[0]));
              break;
            }//sech
          case 15.9: {
            if (Math.round(Math.tanh(inpb[0])*(10))/(10)==0) { //HERE LIES ASY
               asy.push(x)   
                  }
              inpb[0]=1/(Math.tanh(inpb[0]));
              break;
            }//coth
          case 16: {
            inpb[0]=Math.asinh(inpb[0]);
              break;
            }//asinh     
          case 17: {
              inpb[0]=Math.acosh(inpb[0]);
              break;
            }//acosh
          case 18: {
              inpb[0]=Math.atanh(inpb[0]);
              break;
            }//atanh
           
          }
            
            }
          if (fspec>0) {
           if (fspec==5) {inpl.splice(char-2, bil + 4, inpb[0]) 
           } 
            if (fspec>15.9 && fspec<19) {  
              inpl.splice(char-5, bil + 7, inpb[0])              
           } else if (fspec>9 && fspec<16) {
              inpl.splice(char-4, bil + 6, inpb[0])      
           } else {
            inpl.splice(char-3, bil + 5, inpb[0]);
           }
          } else {
          inpl.splice(char, bil + 2, inpb[0]);
          char = char - 1;
          }
        }

        break;
      } //parenthesis + functions
      case ftype - 4: {
        if (inpl[char] == "^") {
          inpl.splice(char - 1, 3, inpl[char - 1] ** inpl[char + 1]);
          char = char - 1;
        }
        break;
      } //exponents/roots
      case ftype - 2: {
        //need to fix still
        if (
          inpl[char] == "*" ||
          inpl[char] == "/" ||
          (!operations.includes(inpl[char + 1]) &&
            !operations.includes(inpl[char]) &&
            inpl[char + 1] !== undefined)
        ) {
          if (inpl[char] == "/") { //ALSO HERE LIES ASY
            
            if (inpl[char + 1] == "-") {
              if (Math.round(-inpl[char + 2]*10)/10==0) {
                asy.push(x)   
                  }
              inpl.splice(char - 1,4, inpl[char - 1] / (-inpl[char + 2]));   
              char = char - 1;
            } else {
              if (Math.round(inpl[char + 1]*10)/10==0) {
                asy.push(x)   
                  }
              inpl.splice(char - 1, 3, inpl[char - 1] / inpl[char + 1]);      
              char = char - 1;
            }
            char = char - 1;
          } else {
            if (
              !operations.includes(inpl[char + 1]) &&
              !operations.includes(inpl[char]) &&
              inpl[char + 1] !== undefined
            ) {
              inpl.splice(char, 2, inpl[char] * inpl[char + 1]);
              char = char - 1;
            } else {
              inpl.splice(char - 1, 3, inpl[char - 1] * inpl[char + 1]);
              char = char - 1;
            }
          }
        }
        break;
      } //mult + divis
      case ftype: {
          //final stuff here for add + subtract
          if (inpl[char] == "+" || inpl[char] == "-") {
            if (inpl[char] == "+") {
              inpl.splice(char - 1, 3, inpl[char - 1] + inpl[char + 1]);
              char = char - 1;
            } else {
              if (char == 0 || operations.includes(inpl[char - 1])) {
                inpl.splice(char, 2, -inpl[char + 1]);
              } else {
                inpl.splice(char - 1, 3, inpl[char - 1] - inpl[char + 1]);
                char = char - 1;
              }
            }
            //should be last thing going on in whole script

            break;
          }
          if (char == inp.length) {
          }
        } //add + subtract
    }
  }

} //solves list input 

function fun() {
  stroke("#009688")
  strokeWeight(0.5)
  noFill()
  for (var i=0; i < yvalues.length; i++) {
  if (yvalues[i]>gmax)
  {yvalues[i]=gmax  
  }
    if (yvalues[i]<-gmax)
  {yvalues[i]=-gmax 
  } 
    if (isNaN(yvalues[i])|| asy.includes(xvalues[i]))
    {
      if (yvalues[i]>0)
  {yvalues[i]=gmax
  
  }
    if (yvalues[i]<0)
  {yvalues[i]=-gmax
  
  } 
    } else { 

    switch (xst) {
      case -1.1: { //dec
       line(xvalues[i-1]*290+298,-(yvalues[i-1])*165+221,xvalues[i]*290+298,-(yvalues[i])*165+221)
        break;
      }
        case -5.5*(PI/2): { //trig
        line(xvalues[i-1]*46.31408844+294,-(yvalues[i-1])*26.41972055+222,xvalues[i]*46.31408844+294,-(yvalues[i])*26.41972055+222)
        break;
      }
      case -11: { //standard
        line(xvalues[i-1]*28.2+300,-(yvalues[i-1])*16+219,xvalues[i]*28.2+300,-(yvalues[i])*16+219)
        break;
      }
      case -55: {//medium
        line(xvalues[i-1]*5.74+300,-(yvalues[i-1])*3.26+221,xvalues[i]*5.74+300,-(yvalues[i])*3.26+221)
        break;
      }
        case -105: {//large
        line(xvalues[i-1]*2.9+299,-(yvalues[i-1])*1.65+221,xvalues[i]*2.9+299,-(yvalues[i])*1.65+221)
        break;
      }
        case -550: {//Xlarge
        line(xvalues[i-1]*0.578+299,-(yvalues[i-1])*0.33+221,xvalues[i]*0.578+299,-(yvalues[i])*0.33+221)
        break;  
      }        
    }
    }
 }
  noStroke()
  fill("white")
  rect(0,0,600,50)
  rect(0,390,600,50)
  stroke("black")
  fill("black")
  txt()
} //draws function

function txt () {
    textSize(30)
  text ("Grapher",240,33)
      textSize(20)
text("y=", 0, 30);
console.log("inpl", inpl);
// console.log("final inp", inp);
console.log("inplt", inplt);
console.log("final ys", yvalues);
//console.log("final xs", xvalues);
//console.log(asy)
} //draws text