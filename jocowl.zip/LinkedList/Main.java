import java.util.LinkedList;
class Main {
  public static void main(String[] args) {
    LinkedList<String> list = new LinkedList<String>();
    list.add("red");
    list.add("orange");
    list.add("yellow");
    list.add("green");
    list.add("blue");
    list.add("purple");
  }
}