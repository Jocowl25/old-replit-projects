class Main {
  public static void main(String[] args) {
    Shape[] shape= new Shape[5];
    for(int i=0;i<5;i++) {
      if(i%2==0) {
        shape[i]=new Rectangle(i+1,i+2);
      }
      else {
        shape[i]=new Triangle(i+1, i+2);
      }
    }
    for(int i=0;i<5;i++) {
      System.out.println("Area: "+shape[i].getArea()+" Perimeter: "+shape[i].getPerimeter());
    }
    for(Shape s:shape) {
      System.out.println(s.getArea());
    }
  }
}