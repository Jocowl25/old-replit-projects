public abstract class Shape {
  private String name="";
  public Shape() {
    name="no name";
  }
  public Shape(String name) {
    this.name=name;
  }
  public abstract int getArea();
  public abstract int getPerimeter();
}