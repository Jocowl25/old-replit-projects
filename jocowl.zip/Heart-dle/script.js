let allWords;
let banned=[];
let wordObjectList=[];
async function getFile(fileURL){
		let fileContent = await fetch(fileURL);
		fileContent = await  fileContent.text(); 
		return fileContent;   									 
}
getFile('en.txt').then(content =>{ 
allWords= content.trim().split("\n").filter((ele)=>ele.length==3||ele.length==7||ele.length==11||ele.length==9);
	game();});
//add blank spaces here 
const banList=`01-11-51-91-t1-02-12-32-52-72-92-t2-14-34-54-74-94-06-16-36-56-76-96-t6-07-17-97-t7-08-09-18-19-28-29-38-39-78-79-88-89-98-99-t8-t9-58-0t-1t-2t-3t-4t-5t-6t-7t-8t-9t-tt-00-10-20-30-40-50-60-70-80-90-t0-`
const gridWidth=11; //dimensions of grid
const width=40; //dimensions of boxes
const margin=width*1.2; //2nd number is margin
const dist=gridWidth*(margin/2); //refrence value for centering entire grid
//key for where letters should be, dash is blank space (roughly)
const key="-------------h-u-g--m-i-t-----e--i--i--e---s-p-r-i-n-g-s-t-e-e-n-e--e--g--s--n--o-e-s-t-r-e-e-t-b-a-n-d---i--r--r--g-----c-h-a-l-i-c-e-------l--k---------e-w-e---------------".split("-");
//which indexes are green by default
const keep=["13","19","79","85"];
//scroll to bottom for further word initialization
let moveId=false;
let mouseX;
let mouseY;
let mouseUp;
let identifier=0
let boxes=[];
document.addEventListener("mousemove",(e)=>{
				if(e.clientX>0&&e.clientX<window.innerWidth){
				mouseX=e.clientX;
				}
	if(e.clientY>0&&e.clientY<window.innerHeight){
				mouseY=e.clientY;
	}
			})
document.addEventListener("mouseup",()=>{
			mouseUp=true;
			})	
document.addEventListener("mousedown",()=>{
			mouseUp=false;
			})	
document.addEventListener("touchmove",(e)=>{
				if(e.touches[0].clientX>0&&e.touches[0].clientX<window.innerWidth){
				mouseX=e.touches[0].clientX;
				}
	if(e.touches[0].clientY>0&&e.touches[0].clientY<window.innerHeight){
				mouseY=e.touches[0].clientY;
	}
			})
document.addEventListener("touchend",(e)=>{
	mouseUp=true;
			})	
document.addEventListener("touchstart",(e)=>{
			mouseUp=false;
	mouseX=e.touches[0].clientX;
	mouseY=e.touches[0].clientY;
			})	
class box {
	constructor(div,x,y,letter,color) {
	 this.div=div;
		div.style.width=width+"px";
		div.style.height=width+"px";
		div.style.fontSize=(width*3/4)+"px";
		this.vx = x;
		this.vy = y;
		this.prevx;
		this.prevy;
		this.free=false;
		this.move=true;
		this.vletter=letter.toUpperCase();
		this.color=color;
	div.addEventListener("mousedown",()=>{
		this.div.style.transition="none"
		if(this.move){
			if(!this.free){
		this.div.style.zIndex=101;
		this.div.style.boxShadow="0px 0px 19px -1px grey";
		this.prevx=this.x();
		this.prevy=this.y();
		this.free=true;
		this.x(mouseX-(width/2))
		this.y(mouseY-(width/2))
		moveId=true;
			}
		}
		});
		div.addEventListener("mouseup",()=>{
			if(moveId){
				moveId=false;
			this.free=false;
			this.div.style.zIndex=2;
			this.div.style.boxShadow="";
			this.x(Math.round((this.x()-(window.innerWidth/2-dist))/margin));
			this.y(Math.round((this.y()-(window.innerHeight/2-dist))/margin));
			this.fix();
				check();
			}
		});
		document.addEventListener("mousemove",(e)=>{
			if(mouseUp&&this.free){
					this.free=false;
					this.x(this.prevx);
				this.y(this.prevy);
				this.div.style.zIndex=2;
				moveId=false;
			}
			if(this.free){
						this.x(mouseX-width/2);
						this.y(mouseY-width/2);
				}	
			})	
	div.addEventListener("touchstart",(e)=>{
		if(!moveId){
		this.div.style.transition="none"
		if(this.move){
			if(!this.free){
				identifier=e.changedTouches[0]
		this.div.style.zIndex=101;
		this.div.style.boxShadow="0px 0px 19px -1px grey";
		this.prevx=this.x();
		this.prevy=this.y();
		this.free=true;
				mouseX=e.touches[0].clientX;
	mouseY=e.touches[0].clientY;
		this.x(mouseX-(width/2))
		this.y(mouseY-(width/2))
		moveId=true;
			}
		}
		}
		});
		div.addEventListener("touchend",(e)=>{
			if(moveId){
				moveId=false;
			this.free=false;
			this.div.style.zIndex=2;
			this.div.style.boxShadow="";
			this.x(Math.round((this.x()-(window.innerWidth/2-dist))/margin));
			this.y(Math.round((this.y()-(window.innerHeight/2-dist))/margin));
			this.fix();
			check();
			}
		});
		document.addEventListener("touchmove",(e)=>{
			if(mouseUp&&this.free){
					this.free=false;
					this.x(this.prevx);
				this.y(this.prevy);
				this.div.style.zIndex=2;
				moveId=false;
			}
			if(this.free){
						this.x(mouseX-width/2);
						this.y(mouseY-width/2);
				}	

			})	
	}
	x(val){
		let a;
		this.free?a=1:a=margin;
		this.div.style.left=(val*a)+"px";
if(!this.free){
		this.div.style.left=`calc(50vw - ${dist}px + ${(val*a)}px)`;
}
			if(val!=null){
		this.vx=val;
		}
		return this.vx;
	}
	 y(val){
		let b;
		this.free?b=1:b=margin;
		this.div.style.top=(val*b)+"px";
		 if(!this.free){
		this.div.style.top=`calc(50vh - ${dist}px + ${(val*b)}px)`;
}
		 if(val!=null){
		this.vy=val;
		}
		return this.vy;
	}
	 letter(val){
		 if(val!=null){
			 this.div.innerHTML=val.toUpperCase();
		 this.vletter=val.toLowerCase();
		 }
		 return this.vletter;
	}
	fix(){
		this.div.style.transition=""
		if(this.y()>-1&&this.x()>-1&&this.x()<gridWidth&&this.y()<gridWidth&&!(banned.includes(`${this.x()}${this.y()}`))){
			let i=PtoI(this.x(),this.y())
				if(boxes[i]!=""){
					boxes[i].div.style.transition="top 0.1s,left 0.1s"
					boxes[i].x(this.prevx);
					boxes[i].y(this.prevy);
					let tmp=boxes[i]
					boxes[i]=this;
					boxes[PtoI(this.prevx,this.prevy)]=tmp;
				}
			this.div.style.transition=""
			return 1;
			}else{
				this.x(this.prevx);
				this.y(this.prevy);
				return 0;
			}
	}
	set color(val){
		this.div.style.borderBottom="4px solid"
		switch(val){
			case 1:
				this.div.style.backgroundColor="lightgrey";
				this.div.style.color="black";
				this.div.style.borderBottomColor="hsl(45,1%,49%)"
				break;
			case 2:
				this.div.style.backgroundColor="hsl(45,90%,60%)";
				this.div.style.color="white";
				this.div.style.borderBottomColor="hsl(45,60%,60%)"
				break;
			case 3:
				this.div.style.backgroundColor="hsl(136,85%,42%)";
				this.div.style.color="white";
				this.div.style.borderBottomColor="hsl(136,55%,42%)"
				banned.push(`${this.x()}${this.y()}`);
				this.move=false;
				break;
		}
	}
}

class word{
	constructor(word,xmin,xmax,ymin,ymax){
		this.word=word.split('');
		this.xmin=xmin;
		this.xmax=xmax;
		this.ymin=ymin;
		this.ymax=ymax;
		this.greenlist=[];
		this.yellowList=[];
	}
}

function PtoI(x,y){ //coord point to array index
	return y*gridWidth+x
}

function ItoP(c,val){ //array index to coord point (c=1 is x, else is y)
	if(c==1){
	return (val)%gridWidth
	}else{
	return Math.ceil(val/gridWidth)
	}
}

function setBannedList(){
	let tmp="";
for(let i=0;i<=banList.length;i++){
	if(banList.charAt(i)=="-"){
		banned.push(tmp);
		tmp=""
	}else{
		if(banList.charAt(i)=="t"){
			tmp=tmp+"10"
		}else{
		tmp=tmp+banList.charAt(i);
		}
	}
}
}

function shuffle(box){
	if(box!=""&&box.move){
		box.prevx=box.x()
		box.prevy=box.y()
		box.x(Math.floor(Math.random() * ((gridWidth-1) - 0 + 1)) + 0);
		box.y(Math.floor(Math.random() * ((gridWidth-1) - 0 + 1)) + 0);
		if(box.fix()==0){
			shuffle(box);
		}
	}
}

function reset(){
	banned=[];
	setBannedList();
	boxes.forEach((ele)=>{
		if(ele!=""){
			if(ele.x()!=(ele.div.id)%(gridWidth)&&ele.y!=Math.floor(ele.div.id/gridWidth)){
				ele.prevx=ele.x()
				ele.prevy=ele.y()
				ele.x((ele.div.id)%(gridWidth))
				ele.y(Math.floor(ele.div.id/gridWidth))
				ele.fix();
			}
			if(keep.includes(ele.div.id)){
				ele.move=false;
			 ele.color=3;
			}else{
				ele.move=true;
			 ele.color=1;
			}
		}
	});
	boxes.forEach((ele)=>{
		shuffle(ele)
	});
	check();
}
function check(){
	wordObjectList.forEach((word)=>{
		word.greenlist=[];
		word.yellowlist=[];
	})
	//check green
		boxes.forEach((ele)=>{
			if(ele!=""){
				ele.color=1;
				if(ele.letter()==key[PtoI(ele.x(),ele.y())]){
					ele.color=3;
					wordObjectList.forEach((word)=>{
						if(word.word.includes(ele.letter())&&ele.x()>=word.xmin&&ele.x()<=word.xmax&&ele.y()>=word.ymin&&ele.y()<=word.ymax){
							word.greenlist.push(ele.letter());
						}
					})
				}
			}
		})
	if(boxes.every((ele)=>{return !ele.move})){
			setTimeout(win(),100)
	}else{
		boxes.forEach((ele)=>{
			if(ele!=""&&ele.move){
				ele.color=1;
				wordObjectList.forEach((word)=>{
						if(word.word.includes(ele.letter())&&ele.x()>=word.xmin&&ele.x()<=word.xmax&&ele.y()>=word.ymin&&ele.y()<=word.ymax){
							if(includesNum(word.yellowlist,ele.letter())+includesNum(word.greenlist,ele.letter())<includesNum(word.word,ele.letter())){
								ele.color=2;
								word.yellowlist.push(ele.letter());
							}
						}
				})
			}
		})
	}
}

function includesNum(array,want){
	let count=0;
	array.forEach((item)=>{
		if(item==want){
			count++
		}
	})
	return count;
}
function game(){
	setBannedList();
	document.getElementById("load").innerHTML="";
	for(let i=1;i<gridWidth**2+1;i++){
		if(!(banned.includes(`${ItoP(1,i-1)}${ItoP(2,i)-1}`))){
		let ne=document.getElementById("box").cloneNode(true);
		document.body.appendChild(ne);
		ne.id=i-1;
		ne.style.display="flex";
		boxes.push(new box(ne,0,0,"a",1));
		boxes[boxes.length-1].x(ItoP(1,i-1));
		boxes[boxes.length-1].y(ItoP(2,i)-1);
		boxes[boxes.length-1].letter(key[i-1]);
			if(keep.includes(boxes[boxes.length-1].div.id)){
						boxes[boxes.length-1].color=3;
				 }
		}else{
			boxes.push("");
		}
	}
	boxes.forEach((ele)=>shuffle(ele));
		wordObjectList.push(new word("hug",2,4,1,1))
		wordObjectList.push(new word("mit",6,8,1,1))
		wordObjectList.push(new word("see",0,0,3,5))
		wordObjectList.push(new word("nod",10,10,3,5))
		wordObjectList.push(new word("ewe",4,6,9,9))
		wordObjectList.push(new word("springsteen",0,10,3,3))
		wordObjectList.push(new word("estreetband",0,10,5,5))
		wordObjectList.push(new word("chalice",2,8,7,7))
		wordObjectList.push(new word("heretic",2,2,1,7))
		wordObjectList.push(new word("gingerale",4,4,1,9))
		wordObjectList.push(new word("misstrike",6,6,1,9))
	wordObjectList.push(new word("teenage",8,8,1,7))
	check();
}
function win(){
	let onlyBox=boxes.filter((ele)=>ele!="")
	onlyBox.forEach((ele,index)=>{
		ele.div.style.animation="done 3s ease-out";
		setTimeout(()=>{
			ele.div.offsetHeight;
			ele.div.style.transition="all 2s ease-out";
			ele.div.style.transform="rotateY(360deg)";
		},index*20+40)
	});
}

function choose(){
	
}
