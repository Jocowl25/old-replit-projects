import java.io.IOException;
import java.net.MalformedURLException;


class Main {
  public static void main(String[] args) throws MalformedURLException, IOException {
    ReplitDBHandler db = new ReplitDBHandler();
    System.out.println("Setting DB key");
    db.setKey("testing1234{}\\\'\'\"\"=+-~!?", Math.random() + "");
    System.out.println("Key List:");
    System.out.println(db.getKeys());
    System.out.println("DB key testing1234{}\\\'\'\"\"=+-~!?: " + db.getKey("testing1234{}\\\'\'\"\"=+-~!?"));
  }
}