// Set this to the correct package
package repl.it.amazingmech2418.javadb;

// Import lib
import java.util.HashMap;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

class ReplitDBHandler {
  private String baseURL;
  public ReplitDBHandler() {
    if(System.getenv("DB") != "" && System.getenv("DB") != null)
      this.baseURL = System.getenv("DB");
    else
      this.baseURL = System.getenv("REPLIT_DB_URL");
  }
  public ReplitDBHandler(String url) {
    this.baseURL = url;
  }
  public void setKey(String key, String value) throws MalformedURLException, IOException {
    HashMap<String, String> data = new HashMap<String, String>();
    data.put(URLEncoder.encode(key, "UTF-8").replaceAll("\\+", "%20"), value);
    Request.POST(this.baseURL, DataBuilder.build(data));
  }
  public String getKey(String key) throws MalformedURLException, IOException {
    return Request.GET(this.baseURL + "/" + URLEncoder.encode(key, "UTF-8").replaceAll("\\+", "%20"));
  }
  public ArrayList<String> getKeys() throws MalformedURLException, IOException {
    String data = Request.GET(this.baseURL + "?prefix=");
    ArrayList<String> result = new ArrayList<String>(Arrays.asList(data.split("\n")));
    return result;
  }

  public void deleteKey(String key) throws MalformedURLException, IOException {
    Request.DELETE(this.baseURL + "/" + URLEncoder.encode(key, "UTF-8").replaceAll("\\+", "%20"));
  }
}