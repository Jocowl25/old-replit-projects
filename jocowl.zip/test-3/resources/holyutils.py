"""
HolyUtils
A project for a simple library of useful functions.
Programmed by TheHolyBread
"""

class IO():

  @staticmethod
  def getnum(msg: str, min: int = None, max: int = None, fail_message: str = "Please enter a number"):

    """Prints a message and asks for an integer. If the user does not provide an integer, the function will ask again. Min and Max param are for minimum and maximum value. Default is set to no minimum and maximum value. Fail_message is the message that is printed if the user does not enter an integer or valid number."""

    number = input(msg)
    try:
      number = int(number)
      if min != None and number < min: int("error :)")
      if max != None and number > min: int("error :)")
    except:
      print('\033[1A\033[2K', end='')
      print(f'\u001B[1m\u001B[31m{fail_message}\n\u001B[39m\u001B[22m')
      while True:
        print('\033[1A\033[2K', end='')
        number = input(msg)
        try:
          number = int(number)
          if min != None and number < min: int("error :)")
          if max != None and number > min: int("error :)")

          print('\033[1A\033[2K', end='', flush=True)
          print(' ' * len(msg + str(number)))
          print('\033[2A\033[2K', end='', flush=True)
          print(' ' * len(msg + str(number)))
          print('\033[1A\033[2K', end='', flush=True)
          print(msg + str(number))
          break
        except:
          pass
    return number


  @staticmethod
  def cprint(text: str, color: str, end: str | None = "\n"):

    """Works like a normal print statement, but with a color. The color can be set to any of the following: red, green, yellow, blue, purple, cyan, white, or black."""

    if color == 'red':
      print('\u001B[31m' + text + '\u001B[39m', end=end)
    elif color == 'green':
      print('\u001B[32m' + text + '\u001B[39m', end=end)
    elif color == 'yellow':
      print('\u001B[33m' + text + '\u001B[39m', end=end)
    elif color == 'blue':
      print('\u001B[34m' + text + '\u001B[39m', end=end)
    elif color == 'purple':
      print('\u001B[35m' + text + '\u001B[39m', end=end)
    elif color == 'cyan':
      print('\u001B[36m' + text + '\u001B[39m', end=end)
    elif color == 'white':
      print('\u001B[37m' + text + '\u001B[39m', end=end)
    elif color == 'black':
      print('\u001B[30m' + text + '\u001B[39m', end=end)
    else:
      raise Exception(f"Invalid color ({color}) \nColor must be red, green, yellow, blue, purple, cyan, white, or black")

  @staticmethod
  def c(text: str, color: str):

    """Returns the specified string, but with a color. The color can be set to any of the following: red, green, yellow, blue, purple, cyan, white, or black."""

    if color == 'red':
      return '\u001B[31m' + text + '\u001B[39m'
    elif color == 'green':
      return '\u001B[32m' + text + '\u001B[39m'
    elif color == 'yellow':
      return '\u001B[33m' + text + '\u001B[39m'
    elif color == 'blue':
      return '\u001B[34m' + text + '\u001B[39m'
    elif color == 'purple':
      return '\u001B[35m' + text + '\u001B[39m'
    elif color == 'cyan':
      return '\u001B[36m' + text + '\u001B[39m'
    elif color == 'white':
      return '\u001B[37m' + text + '\u001B[39m'
    elif color == 'black':
      return '\u001B[30m' + text + '\u001B[39m'
    else:
      raise Exception(f"Invalid color ({color}) \nColor must be red, green, yellow, blue, purple, cyan, white, or black")

  @staticmethod
  def printf(text: str):

    """Prints a message with no automatic linebreak, similare to the normal c printf() function."""

    print(text, end='')

  @staticmethod
  def b(text: str):

    """Returns a string but when printed will be bold"""

    return '\u001B[1m' + text + '\u001B[22m'

  @staticmethod
  def i(text: str):

    """Returns a string but when printed will be italicized"""

    return '\u001B[3m' + text + '\u001B[23m'

  @staticmethod
  def u(text: str):

    """Returns a string but when printed will be underlined"""

    return '\u001B[4m' + text + '\u001B[24m'

  @staticmethod
  def s(text: str):

    """Returns a string but when printed will be strikethrough"""

    return '\u001B[9m' + text + '\u001B[29m'

  @staticmethod
  def choice(msg: str, options: list):

    """Prints the designated message and prompts the user for a choice. If the response is not in the list of options, the function will ask again. Returns a string. You can make the options only numbers then convert the response an int after, but it is suggested to use IO.getnum() instead."""

    options = [str(x) for x in options]
    response = input(msg)
    if response not in options:
      print('\033[1A\033[2K', end='')
      print('\u001B[1m\u001B[31mPlease enter a valid choice\n\u001B[39m\u001B[22m')
      while True:
        print('\033[1A\033[2K', end='')
        response = input(msg)
        if response in options:
          print('\033[1A\033[2K', end='', flush=True)
          print(' ' * len(msg + response))
          print('\033[2A\033[2K', end='', flush=True)
          print(' ' * len(msg + response))
          print('\033[1A\033[2K', end='', flush=True)
          print(msg + response)
          break
    return response

class nums():

  @staticmethod
  def comma(number: int):
    """Returns a string with commas every three digits."""

    return '{:,}'.format(number)