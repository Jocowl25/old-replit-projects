import requests
import os
from resources.holyutils import IO
import resources.textbox as textbox
from time import sleep

user = None
pswrd = None

# https://2d18413b-c461-4739-a777-b92d9934bb77-00-135dzzvdpme9i.picard.replit.dev/

def request(method, data = None):
  url = "https://d220a012-63b0-495a-b065-fc874147e482-00-2wmsgyp7hxs34.kirk.repl.co/"

  r = requests.post(url, json={
    "m": method,
    "d": data
  })
  return r.json()

def menuNoAcc():
  global user
  global pswrd
  print(
f"""
{IO.c("Consocial", 'blue')}
1. Login
2. Register
3. Quit
""")
  choice = IO.choice("> " , ["1", "2", "3"])
  if choice == "1":
    username = input("Username: ")
    password = input("Password: ")
    result = request("get_id", {
      "username": username,
      "password": password
    })
    if result['user_id']:
      user = result['user_id']
      pswrd = password
      IO.cprint(f"Login successful. Logged in as {user}", 'green')
    else:
      IO.cprint(result['error'], 'red') if result['error'] else IO.cprint('An error occurred', 'red')

  elif choice == "2":
    username = input("Username: ")
    password = input("Password: ")
    result = request("post_id", {
      "username": username,
      "password": password
    })
    if result['user_id']:
      user = result['user_id']
      pswrd = password
      IO.cprint(f"Register successful. Logged in as {user}", 'green')
    else:
      IO.cprint(result['error'], 'red') if result['error'] else IO.cprint('An error occurred', 'red')

  elif choice == "3":
    return -1

  sleep(1)
  input("Press enter to continue...")

def menuYesAcc():
  global user
  print(
f"""
{IO.c("Consocial", 'blue')}
Logged in as {IO.b(user)}
1. Recent Posts
2. Create Post
3. Logout
4. Quit
""")
  choice = IO.choice("> " , ["1", "2", "3", "4"])
  if choice == "1":
    IO.cprint("Loading...", 'blue')
    result = request("get_posts", {
      'user': user,
      'pass': pswrd
      })
    result = result['posts']
    i = len(result) - 1
    n = 0
    amount = 10
    while True:
      if i < 0 or n > amount:
        break
      print(f"""
==================
{result[i][0]}

{result[i][1]}
==================
""")
      i -= 1
      n += 1



  elif choice == "2":
    os.system('clear')
    content = textbox.cranbox()
    print(content)
    if IO.choice("Create post? [y/n]: ", ['y','n']) == "y":
      res = request('create_post', {
        'content': content,
        'user': user,
        'pass': pswrd
      })
      print(res['status'])
    else:
      os.system('clear')
      IO.cprint('Post aborted.', 'red')

  elif choice == "3":
    if IO.choice("Are you sure? [y/n]: ", ['y','n']) == 'y':
      user = None
      IO.cprint("Logged out successfully.", 'green')
    else:
      IO.cprint("Logout aborted.", 'red')

  elif choice == "4":
    return -1

  sleep(1)
  input("Press enter to continue...")

IO.cprint("Connecting to server...", 'blue')
try: request("ping")
except: IO.cprint(f"The server is currently offline\nPlease contact TheHolyBread", 'red')
else:
  os.system("clear")
  while True:
    if user:
      if menuYesAcc() == -1: break
    else:
      if menuNoAcc() == -1: break
    os.system('clear')