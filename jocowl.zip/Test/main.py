from scratchclient import ScratchSession
print(get_project(123456).view_count)
