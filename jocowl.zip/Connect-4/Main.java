import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    String[][] board= new String[6][7];
    Scanner inp= new Scanner(System.in);
    int play=1;
    for(int i=0;i<6;i++) {
      for(int j=0;j<7;j++) {
        board[i][j]="-";
      }
    }
    print(board);
    System.out.println("\nWelcome to Connect 4!");
    int turn=1;
    int win=win(board);
    while(win==0) {
      System.out.println("\nPlease input where you want to go Player "+play+ ".");
      input(inp,board,play);
      print(board);
      if(play==1) {
        play=2;
      }
      else {
        play=1;
      }
      win=win(board);
      if(turn==42) {
        win=1;
        System.out.println("\nNo one wins! Somehow you got a draw in Connect 4.");
      }
    turn++;
    }
  System.out.println("\nThanks for Playing Connect 4!");
  }
  public static void print(String[][] b) {
    for(int i=0; i<6; i++) {
      System.out.println("");
      for(int j=0; j<7; j++) {
        System.out.print(b[i][j]);
        System.out.print(" ");
      }
    }
  }
  
  public static void input(Scanner i, String[][] b, int play) {
    System.out.println("Pick a spot");
    int spot = i.nextInt();
    if (spot>0 && spot<8 && b[0][spot-1]=="-") {
      int y=0;
      for(int q=0; q<6; q++) {
        if (q<7 && b[q][spot-1]=="-") {
          y++;
        } 
        else {
          q=10;
        }
      }
      if (play==1) {
        b[y-1][spot-1]="x";
      } 
      else {
        b[y-1][spot-1]="o";
      }
    }
    else {
      System.out.println("Not a valid spot!");
      input(i,b,play);
    }
  }

  public static int win(String[][] board) {
  for (int i=0; i<6;i++) {
    for (int j=0; j<7;j++) {
      if ((j<=3&&board[i][j]!="-"&&board[i][j+1]!="-"&&board[i][j+2]!="-"&&board[i][j+3]!="-")||(i<=2&&board[i][j]!="-"&&board[i+1][j]!="-"&&board[i+2][j]!="-"&&board[i+3][j]!="-")) {
        if((j<=3&&board[i][j]=="x"&&board[i][j+1]=="x"&&board[i][j+2]=="x"&&board[i][j+3]=="x")||(i<=2&&board[i][j]=="x"&&board[i+1][j]=="x"&&board[i+2][j]=="x"&&board[i+3][j]=="x")) {
          System.out.println("\nPlayer 1 Wins!");
          return 1;
        }
        else if ((j<=3&&board[i][j]=="o"&&board[i][j+1]=="o"&&board[i][j+2]=="o"&&board[i][j+3]=="o")||(i<=2&&i<3&&board[i][j]=="o"&&board[i+1][j]=="o"&&board[i+2][j]=="o"&&board[i+3][j]=="o"))
        {
          System.out.println("\nPlayer 2 Wins!");
          return 1;
        }
      }
      if((j<=3&&i<=2&&board[i][j]!="-"&&board[i+1][j+1]!="-"&&board[i+2][j+2]!="-"&&board[i+3][j+3]!="-")||(j<=3&&i<=2&&board[i+3][j]!="-"&&board[i+2][j+1]!="-"&&board[i+1][j+2]!="-"&&board[i][j+3]!="-")){
        if((j<=3&&i<=2&&board[i][j]=="x"&&board[i+1][j+1]=="x"&&board[i+2][j+2]=="x"&&board[i+3][j+3]=="x")||(j<=3&&i<=2&&board[i+3][j]=="x"&&board[i+2][j+1]=="x"&&board[i+1][j+2]=="x"&&board[i][j+3]=="x")){
          System.out.println("\nPlayer 1 Wins!");
          return 1;
        }
        else if((j<=3&&i<=2&&board[i][j]=="o"&&board[i+1][j+1]=="o"&&board[i+2][j+2]=="o"&&board[i+3][j+3]=="o")||(j<=3&&i<=2&&board[i+3][j]=="o"&&board[i+2][j+1]=="o"&&board[i+1][j+2]=="o"&&board[i][j+3]=="o")){
          System.out.println("\n Player 2 Wins!");
          return 1;
        }
      }
    }    
  }
  return 0;
  }
}