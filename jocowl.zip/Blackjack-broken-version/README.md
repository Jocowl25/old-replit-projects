# JavaDB

Welcome to JavaDB. JavaDB is a ReplDB API for the Java programming language! This helps you create databases for your Java repls! 

## Setup

To set up JavaDB in your repl, just copy all of the files in the JavaDB folder. Also, you should preferably copy this file to give proper credit, but feel free to rename it. Repl.it will automatically compile the package, so don't worry about compiling it yourself!

## Usage

To use JavaDB, you first need to use the following import command:
```java
import repl.it.amazingmech2418.javadb.*;
```

You also need the following for error catching:
```java
import java.io.IOException;
import java.net.MalformedURLException;
```
You also need to include in any methods you use JavaDB in `throws IOException, MalformedURLException` unless you use try...catch.

Then, you need to go to your `main` method and create your ReplitDBHandler object.
```java
ReplitDBHandler db = new ReplitDBHandler();
```
You could also specify a URL as a parameter for the constructor.

Now, you can use `db` to modify your database. 

### Getting a list of keys

To get a list of keys, you first need to import `java.util.ArrayList`. Then, you create an `ArrayList` of strings that is set to `db.getKeys()`. Then, you can use `ArrayList` methods to use this data. You could also just directly print the value as is done in this demo repl.

### Getting a key's value

To get a key's value, you simply use `db.getKey("yourkey")`. The key must be present in the database or an error will be thrown. The key name, however, can include any unicode characters.

### Setting a key's value

To set a key's value, you simply use `db.setKey("yourkey", "yourvalue")`. If the key does not exist, this will create it. The key name and value can contain any unicode characters you wish.

### Deleting a key

To delete a key, you simply use `db.deleteKey("yourkey")`. Like with getting a key's value, the key must already be in the database.

## Credits

Thank you @EpicGamer007 and @amaddentcsec for inspiring this with your own ReplDB client and JavaSocial respectively!



## Thank you!

Thank you for using JavaDB by [@AmazingMech2418](https://repl.it/@AmazingMech2418)!