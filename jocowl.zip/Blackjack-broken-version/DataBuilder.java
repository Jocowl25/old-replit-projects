// Set this to the correct package


import java.util.HashMap;

class DataBuilder {
  public static String build(HashMap<String, String> hm) {
    String result = "";
    for(String i : hm.keySet()) {
      result += "&" + i + "=" + hm.get(i);
    }
    return result.substring(1);
  }
}