
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const image =[];
const data=[];
var tmp;
for(i=0;i<100;i++){
	document.getElementById("test").innerHTML=`images...`;
image.push(new Image());
image[i].src = `${i+194}-.png`;
}
document.getElementById("test2").innerHTML=`why...`;
tmp=image[image.length-1];
image[1].addEventListener("load",()=>{console.log("go????")})
image[image.length-1].addEventListener("load", () => {
	document.getElementById("test").innerHTML="processing...";
	for(i=0;i<100;i++) {
		document.getElementById("test2").innerHTML=i;
	const frame=[]
	tmp=image[i];
	ctx.drawImage(tmp, 0, 0,tmp.width/5, tmp.height/5);
	const id = ctx.getImageData(0, 0, tmp.width/5, tmp.height/5);
const imageData=id.data;
	let prepix;
	let pix;
	let prev=1;
	for(a=0;a<imageData.length;a+=4) {
		pix=imageData[a];
		a>3?prepix=imageData[a-4]:prepix=pix
		prepix<100?prepix=0:prepix=255;
		pix<100?pix=0:pix=255;
		 if(prepix!=pix) {
			frame.push(prepix);
			frame.push(prev)
			prev=1;
		} else if(a>3) {prev++}
		if(a==imageData.length-4){
				frame.push(pix);
			if(prepix==pix){frame.push(prev)}
			else{
				frame.push(1);
			}
		}
	}
	//console.log(frame);
	data.push(frame+"m");
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	document.getElementById("test").innerHTML=data;
		console.log(data.length);
	}
	});
console.log(image.length);
