import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner inp= new Scanner(System.in);
    String[][] board= new String[3][3];
    int play= 1;
    
    for (int i=0;i<3;i++) {
      for (int j=0;j<3;j++) {
      board[i][j]="-";
      } 
    }
    System.out.println("\nWelcome to tic tac toe!");
    int turn=1;
    int win=win(board);
    while (win==0) {
      System.out.println("\nPlease input coords Player " + play + ".");
      input(inp,board,play);
      print(board);
      if(play==1){
        play=2;
      } 
      else {
        play=1;
      }
      win=win(board);
      if (turn==9) {
        win=1;
        System.out.println("\nNo One Wins! \nThis was a draw.");
      }
    turn++;
    }
  System.out.println("\n Thanks for playing Tic-Tac-Toe!");
  }
  
  public static void print(String[][] b) {
    for (int i=0;i<3;i++) {
      System.out.println("");
      for (int j=0; j<3; j++) {
        System.out.print(b[i][j]);
      }
    }
  }
  
  public static void input(Scanner i, String[][] b,int play) {
    System.out.println("Input x coord:");
    int x = i.nextInt();
    System.out.println("Input y coord:");
    int y = i.nextInt();
    if (x<10 && x>0 && y<10 && y>0) {
      if (b[y-1][x-1]=="-") {
        if (play==1) {
          b[y-1][x-1]="x";
        } 
        else {
          b[y-1][x-1]="o";
        }
      }
      else {
        System.out.println("Not a valid position. Please retype coords.");
        input(i, b, play);
      }
    } 
    else {
      System.out.println("Not a valid position. Please retype coords.");
      input(i, b, play);
    }
  }

  
  public static int win(String[][] board) {
    for (int i=0;i<3;i++) {
      if ((board[i][0]!="-"&& board[i][1]!="-"&&board[i][2]!="-")||(board[0][i]!="-"&&board[1][i]!="-"&&board[2][i]!="-")) {
        if((board[i][0]=="x"&&board[i][1]=="x"&&board[i][2]=="x")||(board[0][i]=="x"&&board[1][i]=="x"&&board[2][i]=="x")) {
          System.out.println("\nPlayer 1 Wins!");
          return 1;
        } 
        else if((board[i][0]=="o"&&board[i][1]=="o"&&board[i][2]=="o")||(board[0][i]=="o"&&board[1][i]=="o"&&board[2][i]=="o")) {
          System.out.println("\nPlayer 2 Wins!");
          return 1;
        }
    }
  }
    if((board[0][0]=="o"&&board[1][1]=="o"&&board[2][2]=="o")||(board[0][0]=="x"&&board[1][1]=="x"&&board[2][2]=="x")){
      if (board[1][1]=="x") {
        System.out.println("\nPlayer 1 Wins!");
      }
      else{
        System.out.println("\nPlayer 2 Wins!");
      }
      return 1;
    }
    if((board[0][2]=="o"&&board[1][1]=="o"&&board[2][0]=="o")||(board[2][0]=="x"&&board[1][1]=="x"&&board[0][2]=="x")) {
      if(board[1][1]=="x") {
        System.out.println("\nPlayer 1 Wins!");
      } 
      else {
        System.out.println("\nPlayer 2 Wins!");
      }
      return 1;
    }
    return 0;
  }
}