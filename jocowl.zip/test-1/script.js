frame=[]
data=[]
for(i=0;i<2;i++) {
	frame=[i,i+3]
	data.push(frame)}
console.log(data)
console.log(data[0])