import java.util.Random;
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Welcome to the number guesser thing! Type in a number to guess.");
    Random rand=new Random();
    Scanner scan=new Scanner(System.in);
    int inp = scan.nextInt();
    int num=rand.nextInt(10);
    while (num!=inp) {
      if(num>inp) {
        System.out.println("Too Low!");
      }
      if(num<inp) {
        System.out.println("Too High!");
      }
      inp=scan.nextInt();
    }
    System.out.println("You did it! The number was "+ num);
  }
}