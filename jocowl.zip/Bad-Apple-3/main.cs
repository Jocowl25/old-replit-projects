using System;
using System.Drawing;
class Program {
  public static void Main (string[] args) {
		Bitmap  bmp = new Bitmap(@"file:///media/archive/Bad-Apple.zip/599-.png");
  }
}