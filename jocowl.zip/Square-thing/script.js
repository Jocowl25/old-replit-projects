var rx = 200;
var ry = 300;
var s=1;
var x = 0;
var y = 0;
var px;
var py;
var dir = 1;
var inp;
var inp2;
function setup() {
  let cnv=createCanvas(rx, ry);
  cnv.position(10,50)
  noLoop();
   inp = createInput('');
  inp.position(0, 0);
  inp.size(100);
  inp.value(rx);
  inp.input(input);
   inp2 = createInput('');
  inp2.position(0, 30);
  inp2.size(100);
  inp2.value(ry);
  inp2.input(input2);
  inp3 = createInput('');
  inp3.position(120, 0);
  inp3.size(100);
  inp3.value(1);
  inp3.input(input3);
}

function draw() {
  fill("rgb(201,201,201)");
  background(220);
  stroke("black");
  rect(0, 0, Math.floor(rx*s), Math.floor(ry*s));
  x=0;
  y=0;
  dir=1;
  stroke("green");
  noFill();
  beginShape();
  vertex(x, y);
  x++;
  y++;
  while (!((x<=0||x>=Math.floor(rx*s))&&(y<=0||y>=Math.floor(ry*s)))) {
    px=x
    py=y
    dir=logic(x,y,rx,ry,dir);
    switch (dir) {
      case 1: {
        x++;
        y++;
        break;
      }
      case 2: {
        x--;
        y++;
        break;
      }
      case 3: {
        x--;
        y--;
        break;
      }
      case 4: {
        x++;
        y--;
        break;
      }
    }
    line(px,py,x,y);
  }
}
function logic(x,y,rx,ry,dir) {
  if(x==0) {
     if(dir==3) {
       stroke("red")
       return 4;
     }else if(dir==4){
       stroke("blue")
       return 3;
     }else if(dir==2){
       stroke("green");
       return 1;
     }
     }
  if(x==Math.floor(rx*s)) {
     if(dir==2) {
       stroke("green")
       return 1;
     }else if(dir==1){
       stroke("yellow")
       return 2;
     }else if(dir==4){
       stroke("blue")
       return 3;
       }
     }
  if(y==0) {
     if(dir==3) {
       stroke("yellow")
       return 2;
     }else if(dir==4){
       stroke("green")
       return 1;
     }
   }
  if(y==Math.floor(ry*s)) {
     if(dir==2) {
       stroke("blue")
       return 3;
     }else if(dir==3){
       stroke("yellow")
       return 2;
     }else if(dir==1) {
       stroke("red");
       return 4;
     }
   }
  
  return dir;
}
function input() {
  if(this.value()!="") {
  rx=this.value();
resizeCanvas(Math.floor(rx*s), Math.floor(ry*s));
  redraw();
  }
}
function input2() {
  if(this.value()!="") {
  ry=this.value();
resizeCanvas(Math.floor(rx*s), Math.floor(ry*s));
  redraw();
  }
}

function input3() {
  if(this.value()!="") {
  s=this.value();
resizeCanvas(Math.floor(rx*s), Math.floor(ry*s));
  redraw();
  }
}
